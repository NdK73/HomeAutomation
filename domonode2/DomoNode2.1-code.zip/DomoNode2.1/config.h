#pragma once

void readConfig();
